import { pgTable, text, serial, integer, boolean, timestamp, varchar, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (for both volunteers and NGO admins)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  userType: text("user_type").notNull(), // 'volunteer' or 'ngo_admin'
  location: text("location"),
  bio: text("bio"),
  phone: text("phone"),
  profileImage: text("profile_image"),
  skills: text("skills").array(),
  interests: text("interests").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// NGO schema
export const ngos = pgTable("ngos", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  category: text("category").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  website: text("website"),
  logoUrl: text("logo_url"),
  isVerified: boolean("is_verified").default(false).notNull(),
  adminId: integer("admin_id").notNull(), // References users.id
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Categories schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  iconName: text("icon_name").notNull(),
  colorClass: text("color_class").notNull(),
});

// Opportunities schema
export const opportunities = pgTable("opportunities", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  ngoId: integer("ngo_id").notNull(), // References ngos.id
  categoryId: integer("category_id").notNull(), // References categories.id
  location: text("location").notNull(),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  schedule: text("schedule").notNull(), // e.g., "Weekdays", "Weekends", "Flexible"
  duration: text("duration").notNull(), // e.g., "2-3 hours", "Half day"
  requirements: text("requirements"),
  spotsAvailable: integer("spots_available"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Applications schema
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  opportunityId: integer("opportunity_id").notNull(), // References opportunities.id
  volunteerId: integer("volunteer_id").notNull(), // References users.id
  status: text("status").notNull().default("pending"), // "pending", "approved", "rejected"
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Testimonials schema
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // References users.id
  content: text("content").notNull(),
  userType: text("user_type").notNull(), // "volunteer" or "ngo_admin"
  organization: text("organization"), // Only for NGO admins
  location: text("location"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertNgoSchema = createInsertSchema(ngos).omit({ id: true, createdAt: true });
export const insertCategorySchema = createInsertSchema(categories).omit({ id: true });
export const insertOpportunitySchema = createInsertSchema(opportunities).omit({ id: true, createdAt: true });
export const insertApplicationSchema = createInsertSchema(applications).omit({ id: true, createdAt: true, status: true });
export const insertTestimonialSchema = createInsertSchema(testimonials).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type NGO = typeof ngos.$inferSelect;
export type InsertNGO = z.infer<typeof insertNgoSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Opportunity = typeof opportunities.$inferSelect;
export type InsertOpportunity = z.infer<typeof insertOpportunitySchema>;

export type Application = typeof applications.$inferSelect;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;

export type Testimonial = typeof testimonials.$inferSelect;
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
