import Hero from "@/components/home/hero";
import Categories from "@/components/home/categories";
import FeaturedOpportunities from "@/components/home/featured-opportunities";
import FeaturedNGOs from "@/components/home/featured-ngos";
import HowItWorks from "@/components/home/how-it-works";
import Testimonials from "@/components/home/testimonials";
import CTA from "@/components/home/cta";

const Home = () => {
  return (
    <main>
      <Hero />
      <Categories />
      <FeaturedOpportunities />
      <FeaturedNGOs />
      <HowItWorks />
      <Testimonials />
      <CTA />
    </main>
  );
};

export default Home;
