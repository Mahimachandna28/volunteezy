import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import NGOCard from "@/components/ui/ngo-card";
import { type NGO } from "@shared/schema";
import { Search } from "lucide-react";

const NGOs = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [limit, setLimit] = useState(9);

  const { data: ngos, isLoading, error } = useQuery<NGO[]>({
    queryKey: ["/api/ngos"],
  });

  const filteredNGOs = ngos?.filter(
    (ngo) =>
      ngo.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ngo.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ngo.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ngo.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const loadMore = () => {
    setLimit(limit + 6);
  };

  return (
    <div className="bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-10">
          <h1 className="text-3xl leading-8 font-extrabold tracking-tight text-foreground sm:text-4xl">
            Non-Governmental Organizations
          </h1>
          <p className="mt-4 max-w-2xl text-xl text-muted-foreground lg:mx-auto">
            Connect with verified NGOs that are making a difference in communities across the nation.
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="max-w-md mx-auto">
            <div className="relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="text-muted-foreground h-5 w-5" />
              </div>
              <Input
                type="text"
                placeholder="Search for NGOs by name, category, or location"
                className="pl-10 py-3"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(limit)].map((_, i) => (
              <div key={i} className="animate-pulse bg-card overflow-hidden shadow rounded-lg h-52" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center text-destructive">
            Failed to load NGOs. Please try again later.
          </div>
        ) : filteredNGOs && filteredNGOs.length > 0 ? (
          <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {filteredNGOs.slice(0, limit).map((ngo) => (
              <NGOCard key={ngo.id} ngo={ngo} />
            ))}
          </div>
        ) : (
          <div className="text-center text-muted-foreground py-8">
            No NGOs match your search criteria. Try a different search term.
          </div>
        )}

        {filteredNGOs && filteredNGOs.length > limit && (
          <div className="mt-8 text-center">
            <Button variant="outline" onClick={loadMore}>
              Load More Organizations
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default NGOs;
