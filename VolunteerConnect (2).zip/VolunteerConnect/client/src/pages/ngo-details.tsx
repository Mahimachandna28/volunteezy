import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { type NGO, type Opportunity } from "@shared/schema";
import { getCategoryIcon, getColorClass } from "@/lib/icons";
import OpportunityCard from "@/components/ui/opportunity-card";
import { AlertCircle, ArrowLeft, CheckCircle2, MapPin } from "lucide-react";

const NGODetails = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const ngoId = parseInt(id as string);

  const { data: ngo, isLoading: loadingNGO, error: ngoError } = useQuery<NGO>({
    queryKey: [`/api/ngos/${ngoId}`],
    enabled: !!ngoId && !isNaN(ngoId),
  });

  const { data: opportunities, isLoading: loadingOpportunities } = useQuery<Opportunity[]>({
    queryKey: [`/api/opportunities/ngo/${ngoId}`],
    enabled: !!ngoId && !isNaN(ngoId),
  });

  const isLoading = loadingNGO || loadingOpportunities;

  if (ngoError) {
    return (
      <div className="bg-white py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-red-500" />
            <h2 className="mt-2 text-lg font-medium text-gray-900">Organization Not Found</h2>
            <p className="mt-1 text-sm text-gray-500">
              The organization you are looking for does not exist or has been removed.
            </p>
            <div className="mt-6">
              <Button variant="outline" onClick={() => navigate("/ngos")}>
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Organizations
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button 
          variant="outline" 
          onClick={() => navigate("/ngos")}
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Organizations
        </Button>

        {isLoading ? (
          <div className="animate-pulse space-y-8">
            <div className="h-64 bg-white rounded shadow"></div>
            <div className="h-96 bg-white rounded shadow"></div>
          </div>
        ) : ngo ? (
          <>
            <Card className="mb-8">
              <CardContent className="pt-6">
                <div className="md:flex md:items-center">
                  <div className="md:flex-shrink-0 mb-4 md:mb-0 md:mr-6">
                    <img
                      className="h-32 w-32 rounded-lg object-cover mx-auto md:mx-0"
                      src={ngo.logoUrl || "https://via.placeholder.com/200?text=NGO"}
                      alt={`${ngo.name} logo`}
                    />
                  </div>
                  <div>
                    <div className="flex items-center flex-wrap">
                      <h1 className="text-3xl font-bold text-gray-900 mr-2">{ngo.name}</h1>
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle2 className="mr-1 h-3 w-3" /> Verified
                      </Badge>
                    </div>
                    <p className="mt-2 flex items-center text-gray-500">
                      <MapPin className="h-4 w-4 mr-1" /> {ngo.location}
                    </p>
                    <div className="mt-2">
                      <Badge variant="outline" className="mr-2">
                        {ngo.category}
                      </Badge>
                    </div>
                    <p className="mt-4 text-gray-600 max-w-3xl">{ngo.description}</p>
                  </div>
                </div>

                <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6 border-t pt-6">
                  <div className="flex flex-col items-center md:items-start">
                    <span className="text-sm text-gray-500">Contact Email</span>
                    <a 
                      href={`mailto:${ngo.email}`} 
                      className="text-primary-600 hover:underline"
                    >
                      {ngo.email}
                    </a>
                  </div>
                  <div className="flex flex-col items-center md:items-start">
                    <span className="text-sm text-gray-500">Phone</span>
                    <a 
                      href={`tel:${ngo.phone}`} 
                      className="text-primary-600 hover:underline"
                    >
                      {ngo.phone}
                    </a>
                  </div>
                  {ngo.website && (
                    <div className="flex flex-col items-center md:items-start">
                      <span className="text-sm text-gray-500">Website</span>
                      <a 
                        href={ngo.website.startsWith('http') ? ngo.website : `http://${ngo.website}`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary-600 hover:underline"
                      >
                        {ngo.website}
                      </a>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="opportunities" className="mb-6">
              <TabsList>
                <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
                <TabsTrigger value="about">About</TabsTrigger>
              </TabsList>
              
              <TabsContent value="opportunities" className="mt-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Current Volunteering Opportunities</h2>
                {opportunities && opportunities.length > 0 ? (
                  <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                    {opportunities.map((opportunity) => (
                      <OpportunityCard key={opportunity.id} opportunity={opportunity} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-white rounded-lg shadow">
                    <svg 
                      className="mx-auto h-12 w-12 text-gray-400" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={1} 
                        d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" 
                      />
                    </svg>
                    <h3 className="mt-2 text-lg font-medium text-gray-900">No opportunities available</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      This organization does not have any active volunteer opportunities at the moment.
                    </p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="about" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>About {ngo.name}</CardTitle>
                    <CardDescription>Learn more about this organization and its mission</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Mission</h3>
                      <p className="text-gray-600">{ngo.description}</p>
                    </div>
                    
                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Focus Areas</h3>
                      <p className="text-gray-600">
                        {ngo.name} focuses on {ngo.category.toLowerCase()} initiatives in {ngo.location} and surrounding areas.
                      </p>
                    </div>
                    
                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium text-gray-900 mb-2">Contact Information</h3>
                      <div className="space-y-2">
                        <div className="flex items-start">
                          <MapPin className="h-5 w-5 mr-2 text-gray-400" />
                          <span>{ngo.location}</span>
                        </div>
                        <div className="flex items-start">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 mr-2 text-gray-400"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                            />
                          </svg>
                          <a href={`mailto:${ngo.email}`} className="text-primary-600 hover:underline">
                            {ngo.email}
                          </a>
                        </div>
                        <div className="flex items-start">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5 mr-2 text-gray-400"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                            />
                          </svg>
                          <a href={`tel:${ngo.phone}`} className="text-primary-600 hover:underline">
                            {ngo.phone}
                          </a>
                        </div>
                        {ngo.website && (
                          <div className="flex items-start">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 mr-2 text-gray-400"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                              />
                            </svg>
                            <a 
                              href={ngo.website.startsWith('http') ? ngo.website : `http://${ngo.website}`} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-primary-600 hover:underline"
                            >
                              {ngo.website}
                            </a>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        ) : (
          <div className="text-center text-gray-500 py-8">
            Failed to load organization details. Please try again later.
          </div>
        )}
      </div>
    </div>
  );
};

export default NGODetails;
