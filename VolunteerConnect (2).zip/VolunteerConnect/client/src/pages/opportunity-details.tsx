import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent, 
  CardFooter 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type Opportunity, type NGO, type Category, insertApplicationSchema } from "@shared/schema";
import { getCategoryIcon, getColorClass, getOpportunityIcons } from "@/lib/icons";
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  CheckCircle2, 
  AlertCircle,
  ArrowLeft
} from "lucide-react";

const applicationSchema = insertApplicationSchema.extend({
  message: z.string().min(10, {
    message: "Your message must be at least 10 characters long",
  }),
});

type ApplicationFormValues = z.infer<typeof applicationSchema>;

const OpportunityDetails = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const opportunityId = parseInt(id as string);

  const { data: opportunity, isLoading: loadingOpportunity, error: opportunityError } = useQuery<Opportunity>({
    queryKey: [`/api/opportunities/${opportunityId}`],
    enabled: !!opportunityId && !isNaN(opportunityId),
  });

  const { data: ngo, isLoading: loadingNgo } = useQuery<NGO>({
    queryKey: [`/api/ngos/${opportunity?.ngoId}`],
    enabled: !!opportunity?.ngoId,
  });

  const { data: category, isLoading: loadingCategory } = useQuery<Category>({
    queryKey: [`/api/categories/${opportunity?.categoryId}`],
    enabled: !!opportunity?.categoryId,
  });

  const form = useForm<ApplicationFormValues>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      opportunityId: opportunityId,
      volunteerId: 7, // Using hardcoded volunteer ID for demo
      message: "",
    },
  });

  const applyMutation = useMutation({
    mutationFn: (values: ApplicationFormValues) => {
      return apiRequest("POST", "/api/applications", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/applications/volunteer/7`] });
      toast({
        title: "Application Submitted",
        description: "Your application has been submitted successfully!",
        variant: "default",
      });
      setDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to submit application: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: ApplicationFormValues) => {
    applyMutation.mutate(values);
  };

  const isLoading = loadingOpportunity || loadingNgo || loadingCategory;
  const { calendar, location: locationIcon, duration: durationIcon } = getOpportunityIcons();

  const formatDate = (date: Date | null) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (opportunityError) {
    return (
      <div className="bg-background py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-destructive" />
            <h2 className="mt-2 text-lg font-medium text-foreground">Opportunity Not Found</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              The opportunity you are looking for does not exist or has been removed.
            </p>
            <div className="mt-6">
              <Button variant="outline" onClick={() => navigate("/opportunities")}>
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Opportunities
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Button 
          variant="outline" 
          onClick={() => navigate("/opportunities")}
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Opportunities
        </Button>

        {isLoading ? (
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-muted rounded w-1/3"></div>
            <div className="h-64 bg-muted rounded"></div>
            <div className="h-32 bg-muted rounded"></div>
          </div>
        ) : opportunity && ngo && category ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex items-center mb-2">
                    <div className={`h-10 w-10 rounded-full ${getColorClass(category.colorClass)} flex items-center justify-center mr-4`}>
                      {getCategoryIcon(category.iconName)}
                    </div>
                    <div>
                      <CardTitle className="text-2xl">{opportunity.title}</CardTitle>
                      <CardDescription>{category.name} | {ngo.name}</CardDescription>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {opportunity.schedule}
                    </Badge>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                      {opportunity.location}
                    </Badge>
                    <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                      {opportunity.duration}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium text-foreground mb-2">Description</h3>
                    <p className="text-muted-foreground">{opportunity.description}</p>
                  </div>

                  <div className="border-t pt-6">
                    <h3 className="text-lg font-medium text-foreground mb-4">Details</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="flex items-center text-muted-foreground">
                        <Calendar className="h-5 w-5 mr-2 text-muted-foreground" />
                        <span>
                          {opportunity.startDate && opportunity.endDate ? (
                            `${formatDate(opportunity.startDate)} - ${formatDate(opportunity.endDate)}`
                          ) : opportunity.startDate ? (
                            `Starting ${formatDate(opportunity.startDate)}`
                          ) : (
                            opportunity.schedule
                          )}
                        </span>
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <MapPin className="h-5 w-5 mr-2 text-muted-foreground" />
                        <span>{opportunity.location}</span>
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <Clock className="h-5 w-5 mr-2 text-muted-foreground" />
                        <span>{opportunity.duration}</span>
                      </div>
                      <div className="flex items-center text-muted-foreground">
                        <Users className="h-5 w-5 mr-2 text-muted-foreground" />
                        <span>{opportunity.spotsAvailable} spots available</span>
                      </div>
                    </div>
                  </div>

                  {opportunity.requirements && (
                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium text-foreground mb-2">Requirements</h3>
                      <p className="text-muted-foreground">{opportunity.requirements}</p>
                    </div>
                  )}

                  <div className="border-t pt-6">
                    <Button 
                      size="lg" 
                      className="mt-4 w-full sm:w-auto"
                      onClick={() => setDialogOpen(true)}
                    >
                      Apply for this Opportunity
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">About the Organization</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center mb-4">
                    <img
                      src={ngo.logoUrl || "https://via.placeholder.com/100?text=NGO"}
                      alt={ngo.name}
                      className="h-16 w-16 rounded-full object-cover mr-4"
                    />
                    <div>
                      <h3 className="text-lg font-medium">{ngo.name}</h3>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Badge className="mt-1 bg-green-100 text-green-800">
                          <CheckCircle2 className="mr-1 h-3 w-3" /> Verified
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <p className="text-muted-foreground mb-4">{ngo.description}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start">
                      <MapPin className="h-5 w-5 mr-2 text-muted-foreground" />
                      <span className="text-muted-foreground">{ngo.location}</span>
                    </div>
                    <div className="flex items-start">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2 text-muted-foreground"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                        />
                      </svg>
                      <span className="text-muted-foreground">{ngo.email}</span>
                    </div>
                    <div className="flex items-start">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2 text-muted-foreground"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                        />
                      </svg>
                      <span className="text-muted-foreground">{ngo.phone}</span>
                    </div>
                    {ngo.website && (
                      <div className="flex items-start">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5 mr-2 text-muted-foreground"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                          />
                        </svg>
                        <a 
                          href={ngo.website.startsWith('http') ? ngo.website : `http://${ngo.website}`} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-primary-600 hover:underline"
                        >
                          {ngo.website}
                        </a>
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="border-t pt-4">
                  <Button variant="outline" asChild className="w-full">
                    <a href={`/ngos/${ngo.id}`}>View Organization Profile</a>
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        ) : (
          <div className="text-center text-muted-foreground py-8">
            Failed to load opportunity details. Please try again later.
          </div>
        )}
      </div>

      {/* Application Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Apply for Volunteer Opportunity</DialogTitle>
            <DialogDescription>
              Send a message to {ngo?.name} explaining why you're interested in this opportunity and what skills you can bring.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Message</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Tell the organization why you're interested and what skills you can contribute..."
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      This message will be sent to the organization along with your profile information.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={applyMutation.isPending}
                >
                  {applyMutation.isPending ? "Submitting..." : "Submit Application"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default OpportunityDetails;
