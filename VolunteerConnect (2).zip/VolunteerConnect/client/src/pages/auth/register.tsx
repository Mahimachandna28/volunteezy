import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertUserSchema } from "@shared/schema";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { MultiSelect } from "@/components/ui/multi-select";
import { Link } from "wouter";

// Extend the user schema for the volunteer registration form
const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, {
    message: "Password must be at least 6 characters",
  }),
  termsAccepted: z.boolean().refine(val => val === true, {
    message: "You must accept the terms and conditions to register",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

// Define the form values type
type RegisterFormValues = z.infer<typeof registerSchema>;

// Available skills and interests for the multi-select dropdowns
const availableSkills = [
  { value: "Teaching", label: "Teaching" },
  { value: "Mentoring", label: "Mentoring" },
  { value: "Gardening", label: "Gardening" },
  { value: "Cooking", label: "Cooking" },
  { value: "Driving", label: "Driving" },
  { value: "First Aid", label: "First Aid" },
  { value: "Counseling", label: "Counseling" },
  { value: "Marketing", label: "Marketing" },
  { value: "Web Development", label: "Web Development" },
  { value: "Photography", label: "Photography" },
  { value: "Event Planning", label: "Event Planning" },
  { value: "Foreign Languages", label: "Foreign Languages" },
];

const availableInterests = [
  { value: "Education", label: "Education" },
  { value: "Environment", label: "Environment" },
  { value: "Healthcare", label: "Healthcare" },
  { value: "Food Distribution", label: "Food Distribution" },
  { value: "Community Service", label: "Community Service" },
  { value: "Animal Welfare", label: "Animal Welfare" },
  { value: "Arts & Culture", label: "Arts & Culture" },
  { value: "Elderly Care", label: "Elderly Care" },
  { value: "Children & Youth", label: "Children & Youth" },
  { value: "Homelessness", label: "Homelessness" },
  { value: "Disaster Relief", label: "Disaster Relief" },
  { value: "Sports & Recreation", label: "Sports & Recreation" },
];

const locations = [
  "New York",
  "Los Angeles",
  "Chicago",
  "Houston",
  "Phoenix",
  "Philadelphia",
  "San Antonio",
  "San Diego",
  "Dallas",
  "San Jose",
];

const Register = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  // Initialize form with default values
  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      userType: "volunteer",
      location: "",
      bio: "",
      phone: "",
      profileImage: "",
      skills: [],
      interests: [],
      termsAccepted: false,
    },
  });

  // Set up mutation for form submission
  const registerMutation = useMutation({
    mutationFn: (values: RegisterFormValues) => {
      // Remove confirmPassword and termsAccepted before sending to API
      const { confirmPassword, termsAccepted, ...userValues } = values;
      // Include selected skills and interests
      userValues.skills = selectedSkills;
      userValues.interests = selectedInterests;
      
      return apiRequest("POST", "/api/users/register", userValues);
    },
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "Your account has been created successfully. Please log in.",
        variant: "default",
      });
      navigate("/login");
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: RegisterFormValues) => {
    registerMutation.mutate(values);
  };

  return (
    <div className="bg-gray-50 py-12">
      <div className="max-w-md mx-auto px-4 sm:px-6">
        <Card className="shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Register as Volunteer</CardTitle>
            <CardDescription className="text-center">
              Create an account to find volunteering opportunities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="johndoe" {...field} />
                        </FormControl>
                        <FormDescription>
                          This will be your login username
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john.doe@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="******" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="******" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your location" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {locations.map((location) => (
                              <SelectItem key={location} value={location}>{location}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="(123) 456-7890" {...field} />
                        </FormControl>
                        <FormDescription>
                          Optional, but helps NGOs contact you directly
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bio</FormLabel>
                        <FormControl>
                          <Input placeholder="Tell us a bit about yourself" {...field} />
                        </FormControl>
                        <FormDescription>
                          A short description about your volunteering interests
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="skills"
                    render={() => (
                      <FormItem>
                        <FormLabel>Skills</FormLabel>
                        <FormControl>
                          <MultiSelect
                            options={availableSkills}
                            selected={selectedSkills}
                            onChange={setSelectedSkills}
                            placeholder="Select your skills"
                          />
                        </FormControl>
                        <FormDescription>
                          Select skills you can offer as a volunteer
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="interests"
                    render={() => (
                      <FormItem>
                        <FormLabel>Interests</FormLabel>
                        <FormControl>
                          <MultiSelect
                            options={availableInterests}
                            selected={selectedInterests}
                            onChange={setSelectedInterests}
                            placeholder="Select your interests"
                          />
                        </FormControl>
                        <FormDescription>
                          Select causes you're interested in supporting
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="termsAccepted"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            I accept the <a href="#" className="text-primary-600 hover:underline">terms and conditions</a>
                          </FormLabel>
                          <FormDescription>
                            By registering, you agree to our privacy policy and terms of service.
                          </FormDescription>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? "Registering..." : "Register"}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-sm text-center text-gray-500">
              Already have an account?{" "}
              <Link href="/login" className="text-primary-600 hover:underline">
                Sign in
              </Link>
            </div>
            <div className="text-sm text-center text-gray-500">
              Want to register as an organization?{" "}
              <Link href="/register-ngo" className="text-primary-600 hover:underline">
                Register as NGO
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Register;
