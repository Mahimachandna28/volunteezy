import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import OpportunityCard from "@/components/ui/opportunity-card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { type Opportunity, type Category } from "@shared/schema";
import { Search } from "lucide-react";

const FeaturedOpportunities = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedLocation, setSelectedLocation] = useState("all");
  const [selectedSchedule, setSelectedSchedule] = useState("all");
  const [selectedDuration, setSelectedDuration] = useState("all");

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: opportunities, isLoading, error } = useQuery<Opportunity[]>({
    queryKey: ["/api/opportunities", searchTerm, selectedCategory, selectedLocation, selectedSchedule, selectedDuration],
    queryFn: async ({ queryKey }) => {
      const [_, search, category, location, schedule, duration] = queryKey;
      const params = new URLSearchParams();
      if (search) params.append("search", search as string);
      if (category && category !== "all") params.append("category", category as string);
      if (location && location !== "all") params.append("location", location as string);
      if (schedule && schedule !== "all") params.append("schedule", schedule as string);
      if (duration && duration !== "all") params.append("duration", duration as string);
      
      const res = await fetch(`/api/opportunities?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch opportunities");
      return res.json();
    },
  });

  const handleApplyFilters = () => {
    // No need to do anything, the query will automatically refetch with the updated state values
  };

  const locations = ["Andheri, Mumbai", "Adyar, Chennai", "Lajpat Nagar, Delhi", "Jayanagar, Bangalore", "Vasant Kunj, New Delhi", "Hauz Khas, Delhi"];
  const schedules = ["Weekdays", "Weekends", "One-time", "Flexible", "Weekly"];
  const durations = ["1-2 Hours", "2-3 Hours", "3 Hours", "4 Hours", "Half Day", "Full Day"];

  return (
    <section id="opportunities" className="py-12 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-10">
          <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Opportunities</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-foreground sm:text-4xl">
            Featured volunteering opportunities
          </p>
          <p className="mt-4 max-w-2xl text-xl text-muted-foreground lg:mx-auto">
            Join these impactful initiatives and start making a difference today.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 rounded-lg bg-card p-6 shadow-sm">
          <div className="sm:flex sm:items-center sm:justify-between">
            <div className="w-full">
              <div className="relative rounded-md shadow-sm w-full">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="text-muted-foreground h-5 w-5" />
                </div>
                <Input
                  type="text"
                  placeholder="Search opportunities by keyword or location"
                  className="pl-10 py-3"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger id="category">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories?.map((category) => (
                    <SelectItem key={category.id} value={category.id.toString()}>{category.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="location">Location</Label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger id="location">
                  <SelectValue placeholder="All Locations" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  {locations.map((location) => (
                    <SelectItem key={location} value={location}>{location}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="schedule">Schedule</Label>
              <Select value={selectedSchedule} onValueChange={setSelectedSchedule}>
                <SelectTrigger id="schedule">
                  <SelectValue placeholder="Any Schedule" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Schedule</SelectItem>
                  {schedules.map((schedule) => (
                    <SelectItem key={schedule} value={schedule}>{schedule}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="duration">Duration</Label>
              <Select value={selectedDuration} onValueChange={setSelectedDuration}>
                <SelectTrigger id="duration">
                  <SelectValue placeholder="Any Duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Duration</SelectItem>
                  {durations.map((duration) => (
                    <SelectItem key={duration} value={duration}>{duration}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <Button onClick={handleApplyFilters}>
              Apply Filters
            </Button>
          </div>
        </div>

        {/* Opportunities List */}
        {isLoading ? (
          <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="animate-pulse bg-card overflow-hidden shadow rounded-lg h-60" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center text-destructive">
            Failed to load opportunities. Please try again later.
          </div>
        ) : opportunities && opportunities.length > 0 ? (
          <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {opportunities.map((opportunity) => (
              <OpportunityCard key={opportunity.id} opportunity={opportunity} />
            ))}
          </div>
        ) : (
          <div className="text-center text-muted-foreground py-8">
            No opportunities match your search criteria. Try adjusting your filters.
          </div>
        )}

        <div className="mt-8 text-center">
          <Button variant="outline" asChild>
            <a href="/opportunities">View All Opportunities</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedOpportunities;
