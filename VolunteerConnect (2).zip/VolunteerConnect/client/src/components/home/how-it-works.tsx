import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const HowItWorks = () => {
  return (
    <section id="how-it-works" className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-10">
          <h2 className="text-base text-primary-600 font-semibold tracking-wide uppercase">Process</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            How Volunteezy Works
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            A simple process to connect volunteers with meaningful opportunities.
          </p>
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center" aria-hidden="true">
            <div className="w-full border-t border-gray-300"></div>
          </div>
          <div className="relative flex justify-center">
            <span className="px-2 bg-white text-sm text-gray-500">For Volunteers</span>
          </div>
        </div>

        <div className="mt-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
            <div className="relative">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white">
                <span className="text-lg font-bold">1</span>
              </div>
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900">Create Your Profile</h3>
                <p className="mt-2 text-base text-gray-500">
                  Sign up and create your volunteer profile with your skills, interests, and availability. This helps match you with relevant opportunities.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white">
                <span className="text-lg font-bold">2</span>
              </div>
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900">Browse Opportunities</h3>
                <p className="mt-2 text-base text-gray-500">
                  Search and filter volunteer opportunities by category, location, time commitment, and more to find the perfect match.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white">
                <span className="text-lg font-bold">3</span>
              </div>
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900">Apply and Connect</h3>
                <p className="mt-2 text-base text-gray-500">
                  Apply for opportunities directly through the platform, communicate with NGOs, and start making a difference in your community.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="relative mt-12">
          <div className="absolute inset-0 flex items-center" aria-hidden="true">
            <div className="w-full border-t border-gray-300"></div>
          </div>
          <div className="relative flex justify-center">
            <span className="px-2 bg-white text-sm text-gray-500">For NGOs</span>
          </div>
        </div>

        <div className="mt-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
            <div className="relative">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-500 text-white">
                <span className="text-lg font-bold">1</span>
              </div>
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900">Register and Verify</h3>
                <p className="mt-2 text-base text-gray-500">
                  Register your organization, submit necessary documentation for verification, and create a compelling profile.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-500 text-white">
                <span className="text-lg font-bold">2</span>
              </div>
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900">Post Opportunities</h3>
                <p className="mt-2 text-base text-gray-500">
                  Create detailed listings for your volunteer needs with clear descriptions, requirements, and time commitments.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-500 text-white">
                <span className="text-lg font-bold">3</span>
              </div>
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900">Manage Applications</h3>
                <p className="mt-2 text-base text-gray-500">
                  Review volunteer applications, communicate with applicants, and coordinate your volunteering activities efficiently.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Button asChild className="shadow">
            <Link href="/register">Get Started</Link>
          </Button>
          <Button variant="outline" className="mt-3 ml-3 shadow" asChild>
            <Link href="/register-ngo">Learn More</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
