import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { type Testimonial } from "@shared/schema";

const Testimonials = () => {
  const { data: testimonials, isLoading, error } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  return (
    <section id="testimonials" className="py-12 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-10">
          <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Testimonials</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl">
            Success Stories
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 dark:text-gray-400 lg:mx-auto">
            Hear from our community of volunteers and organizations across India.
          </p>
        </div>

        <div className="mt-10">
          {isLoading ? (
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg h-48" />
              ))}
            </div>
          ) : error ? (
            <div className="text-center text-red-500 dark:text-red-400">
              Failed to load testimonials. Please try again later.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
              {testimonials?.map((testimonial) => (
                <Card key={testimonial.id} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <img
                        className="h-12 w-12 rounded-full object-cover"
                        src={testimonial.imageUrl || "https://via.placeholder.com/64"}
                        alt={`Profile of ${testimonial.userType === "volunteer" ? "volunteer" : "NGO representative"} from ${testimonial.location}`}
                      />
                    </div>
                    <div className="ml-4">
                      <h4 className="text-lg font-bold text-gray-900 dark:text-gray-100">
                        {testimonial.userType === "volunteer" ? testimonial.location : testimonial.organization}
                      </h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {testimonial.userType === "volunteer"
                          ? `Volunteer, ${testimonial.location}`
                          : `Program Director, ${testimonial.organization}`}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-gray-600 dark:text-gray-300">{testimonial.content}</p>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
