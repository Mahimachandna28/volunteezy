import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import NGOCard from "@/components/ui/ngo-card";
import { type NGO } from "@shared/schema";

const FeaturedNGOs = () => {
  const { data: ngos, isLoading, error } = useQuery<NGO[]>({
    queryKey: ["/api/ngos"],
  });

  return (
    <section id="ngos" className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-10">
          <h2 className="text-base text-primary-600 font-semibold tracking-wide uppercase">Organizations</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Featured NGOs
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            These verified organizations are actively looking for volunteers like you.
          </p>
        </div>

        {isLoading ? (
          <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="animate-pulse bg-white overflow-hidden shadow rounded-lg h-52" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center text-red-500">
            Failed to load NGOs. Please try again later.
          </div>
        ) : (
          <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {ngos?.map((ngo) => (
              <NGOCard key={ngo.id} ngo={ngo} />
            ))}
          </div>
        )}

        <div className="mt-8 text-center">
          <Button variant="outline" asChild>
            <a href="/ngos">View All Organizations</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedNGOs;
