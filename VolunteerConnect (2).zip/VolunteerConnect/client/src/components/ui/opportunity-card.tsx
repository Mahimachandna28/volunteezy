import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getCategoryIcon, getColorClass, getOpportunityIcons } from "@/lib/icons";
import { type Opportunity } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { type NGO, type Category } from "@shared/schema";

interface OpportunityCardProps {
  opportunity: Opportunity;
}

const OpportunityCard = ({ opportunity }: OpportunityCardProps) => {
  const { data: ngo } = useQuery<NGO>({
    queryKey: [`/api/ngos/${opportunity.ngoId}`],
  });

  const { data: category } = useQuery<Category>({
    queryKey: [`/api/categories/${opportunity.categoryId}`],
  });
  
  const { calendar, location: locationIcon, duration: durationIcon } = getOpportunityIcons();
  
  const formatDate = (date: Date | null) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };
  
  const getScheduleDisplay = () => {
    if (opportunity.startDate && opportunity.endDate) {
      return `${formatDate(opportunity.startDate)}`;
    } else if (opportunity.startDate) {
      return `Starting ${formatDate(opportunity.startDate)}`;
    } else {
      return opportunity.schedule;
    }
  };
  
  const colorClass = category ? getColorClass(category.colorClass) : "bg-gray-100 text-gray-600";
  
  return (
    <Card className="bg-white overflow-hidden shadow rounded-lg border border-gray-200">
      <CardContent className="p-5">
        <div className="flex items-center">
          <div className={`h-10 w-10 rounded-full ${colorClass} flex items-center justify-center`}>
            {category && getCategoryIcon(category.iconName)}
          </div>
          <div className="ml-4">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              {opportunity.title}
            </h3>
            <p className="text-sm text-gray-500">
              {category?.name || "Category"} | {ngo?.name || "Organization"}
            </p>
          </div>
        </div>
        <div className="mt-4">
          <p className="text-gray-600 text-sm">{opportunity.description}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-200">
              {opportunity.schedule}
            </Badge>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-200">
              {opportunity.location}
            </Badge>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800 hover:bg-purple-200">
              {opportunity.duration}
            </Badge>
          </div>
          <div className="mt-4 flex justify-between items-center">
            <div className="text-sm text-gray-500 flex items-center">
              {calendar} {getScheduleDisplay()}
            </div>
            <Button variant="default" size="sm" asChild>
              <Link href={`/opportunities/${opportunity.id}`}>
                Apply Now
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default OpportunityCard;
