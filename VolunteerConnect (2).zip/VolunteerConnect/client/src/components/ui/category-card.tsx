import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { getCategoryIcon, getColorClass } from "@/lib/icons";
import { type Category } from "@shared/schema";

interface CategoryCardProps {
  category: Category;
}

const CategoryCard = ({ category }: CategoryCardProps) => {
  const colorClass = getColorClass(category.colorClass);
  
  return (
    <Card className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5 flex items-center">
        <div className={`flex-shrink-0 ${colorClass} rounded-md p-3`}>
          {getCategoryIcon(category.iconName, "text-xl")}
        </div>
        <div className="ml-5">
          <h3 className="text-lg font-medium text-gray-900">{category.name}</h3>
          <p className="mt-1 text-sm text-gray-500">{category.description}</p>
        </div>
      </div>
      <div className="bg-gray-50 px-5 py-3">
        <div className="text-sm">
          <Link 
            href={`/opportunities?category=${category.id}`} 
            className="font-medium text-primary-600 hover:text-primary-500"
          >
            View opportunities <span aria-hidden="true">&rarr;</span>
          </Link>
        </div>
      </div>
    </Card>
  );
};

export default CategoryCard;
