import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { type NGO } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { type Opportunity } from "@shared/schema";
import { CheckCircle2 } from "lucide-react";

interface NGOCardProps {
  ngo: NGO;
}

const NGOCard = ({ ngo }: NGOCardProps) => {
  const { data: opportunities } = useQuery<Opportunity[]>({
    queryKey: [`/api/opportunities/ngo/${ngo.id}`],
  });

  const activeOpportunities = opportunities ? opportunities.length : 0;

  return (
    <Card className="bg-white shadow overflow-hidden rounded-lg">
      <div className="px-4 py-5 sm:px-6 flex items-center">
        <img
          className="h-16 w-16 rounded-full object-cover"
          src={ngo.logoUrl || "https://via.placeholder.com/200?text=NGO"}
          alt={`${ngo.name} logo`}
        />
        <div className="ml-4">
          <h3 className="text-lg leading-6 font-medium text-gray-900">{ngo.name}</h3>
          <p className="text-sm text-gray-500">
            {ngo.category} | {ngo.location}
          </p>
        </div>
      </div>
      <div className="border-t border-gray-200 px-4 py-4 sm:px-6">
        <p className="text-sm text-gray-600">{ngo.description}</p>
        <div className="mt-4">
          <Badge className="bg-green-100 text-green-800 mr-2 hover:bg-green-200">
            <CheckCircle2 className="-ml-0.5 mr-1.5 h-2 w-2 text-green-400" />
            Verified
          </Badge>
          <span className="text-xs text-gray-500">{activeOpportunities} active opportunities</span>
        </div>
        <div className="mt-4">
          <Link 
            href={`/ngos/${ngo.id}`}
            className="text-sm font-medium text-primary-600 hover:text-primary-500"
          >
            View organization <span aria-hidden="true">&rarr;</span>
          </Link>
        </div>
      </div>
    </Card>
  );
};

export default NGOCard;
