import React from "react";
import { 
  GraduationCap, 
  Sprout, 
  Heart, 
  Utensils, 
  PawPrint,
  HandHeart,
  CalendarDays,
  MapPin,
  Clock
} from "lucide-react";

export const getCategoryIcon = (iconName: string, className?: string) => {
  const iconProps = { className: className || "h-5 w-5" };

  switch (iconName) {
    case "GraduationCap":
      return <GraduationCap {...iconProps} />;
    case "Sprout":
      return <Sprout {...iconProps} />;
    case "Heart":
      return <Heart {...iconProps} />;
    case "Utensils":
      return <Utensils {...iconProps} />;
    case "PawPrint":
      return <PawPrint {...iconProps} />;
    case "HandsHelping":
      return <HandHeart {...iconProps} />;
    default:
      return <HandHeart {...iconProps} />;
  }
};

export const getColorClass = (color: string) => {
  switch (color) {
    case "primary":
      return "bg-primary-100 text-primary-600";
    case "secondary":
      return "bg-green-100 text-green-600";
    case "red":
      return "bg-red-100 text-red-600";
    case "amber":
      return "bg-amber-100 text-amber-600";
    case "purple":
      return "bg-purple-100 text-purple-600";
    case "blue":
      return "bg-blue-100 text-blue-600";
    default:
      return "bg-gray-100 text-gray-600";
  }
};

export const getOpportunityIcons = () => {
  return {
    calendar: <CalendarDays className="h-4 w-4 mr-1" />,
    location: <MapPin className="h-4 w-4 mr-1" />,
    duration: <Clock className="h-4 w-4 mr-1" />
  };
};
