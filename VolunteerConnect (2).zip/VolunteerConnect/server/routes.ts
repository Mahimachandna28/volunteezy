import { Router, type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertNgoSchema, 
  insertOpportunitySchema, 
  insertApplicationSchema, 
  insertTestimonialSchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = Router();
  
  // Helper middleware for handling validation errors
  const validateRequest = (schema: any) => (req: any, res: any, next: any) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      return res.status(400).json({ error: "Invalid request body" });
    }
  };

  // User routes
  apiRouter.post("/users/register", validateRequest(insertUserSchema), async (req, res) => {
    try {
      const { username, email } = req.body;
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already taken" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already registered" });
      }
      
      const user = await storage.createUser(req.body);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Failed to create user" });
    }
  });
  
  apiRouter.post("/users/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Find user by username
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      
      // In a real app, we would hash and compare passwords
      if (user.password !== password) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Login failed" });
    }
  });
  
  apiRouter.get("/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // NGO routes
  apiRouter.post("/ngos", validateRequest(insertNgoSchema), async (req, res) => {
    try {
      const ngo = await storage.createNGO(req.body);
      res.status(201).json(ngo);
    } catch (error) {
      res.status(500).json({ error: "Failed to create NGO" });
    }
  });
  
  apiRouter.get("/ngos", async (req, res) => {
    try {
      const ngos = await storage.getNGOs();
      res.json(ngos);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch NGOs" });
    }
  });
  
  apiRouter.get("/ngos/:id", async (req, res) => {
    try {
      const ngo = await storage.getNGO(parseInt(req.params.id));
      if (!ngo) {
        return res.status(404).json({ error: "NGO not found" });
      }
      res.json(ngo);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch NGO" });
    }
  });
  
  apiRouter.put("/ngos/:id/verify", async (req, res) => {
    try {
      const ngo = await storage.verifyNGO(parseInt(req.params.id));
      if (!ngo) {
        return res.status(404).json({ error: "NGO not found" });
      }
      res.json(ngo);
    } catch (error) {
      res.status(500).json({ error: "Failed to verify NGO" });
    }
  });

  // Category routes
  apiRouter.get("/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });
  
  apiRouter.get("/categories/:id", async (req, res) => {
    try {
      const category = await storage.getCategory(parseInt(req.params.id));
      if (!category) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch category" });
    }
  });

  // Opportunity routes
  apiRouter.post("/opportunities", validateRequest(insertOpportunitySchema), async (req, res) => {
    try {
      const opportunity = await storage.createOpportunity(req.body);
      res.status(201).json(opportunity);
    } catch (error) {
      res.status(500).json({ error: "Failed to create opportunity" });
    }
  });
  
  apiRouter.get("/opportunities", async (req, res) => {
    try {
      const { search, category, location, schedule, duration } = req.query;
      
      if (search || category || location || schedule || duration) {
        const filters = {
          category: category as string,
          location: location as string,
          schedule: schedule as string,
          duration: duration as string
        };
        
        const opportunities = await storage.searchOpportunities(search as string, filters);
        return res.json(opportunities);
      }
      
      const opportunities = await storage.getOpportunities();
      res.json(opportunities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch opportunities" });
    }
  });
  
  apiRouter.get("/opportunities/:id", async (req, res) => {
    try {
      const opportunity = await storage.getOpportunity(parseInt(req.params.id));
      if (!opportunity) {
        return res.status(404).json({ error: "Opportunity not found" });
      }
      res.json(opportunity);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch opportunity" });
    }
  });
  
  apiRouter.get("/opportunities/ngo/:ngoId", async (req, res) => {
    try {
      const opportunities = await storage.getOpportunitiesByNGO(parseInt(req.params.ngoId));
      res.json(opportunities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch opportunities by NGO" });
    }
  });
  
  apiRouter.get("/opportunities/category/:categoryId", async (req, res) => {
    try {
      const opportunities = await storage.getOpportunitiesByCategory(parseInt(req.params.categoryId));
      res.json(opportunities);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch opportunities by category" });
    }
  });

  // Application routes
  apiRouter.post("/applications", validateRequest(insertApplicationSchema), async (req, res) => {
    try {
      const application = await storage.createApplication(req.body);
      res.status(201).json(application);
    } catch (error) {
      res.status(500).json({ error: "Failed to create application" });
    }
  });
  
  apiRouter.get("/applications/opportunity/:opportunityId", async (req, res) => {
    try {
      const applications = await storage.getApplicationsByOpportunity(parseInt(req.params.opportunityId));
      res.json(applications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch applications by opportunity" });
    }
  });
  
  apiRouter.get("/applications/volunteer/:volunteerId", async (req, res) => {
    try {
      const applications = await storage.getApplicationsByVolunteer(parseInt(req.params.volunteerId));
      res.json(applications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch applications by volunteer" });
    }
  });
  
  apiRouter.put("/applications/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      if (!status || !["pending", "approved", "rejected"].includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }
      
      const application = await storage.updateApplicationStatus(parseInt(req.params.id), status);
      if (!application) {
        return res.status(404).json({ error: "Application not found" });
      }
      
      res.json(application);
    } catch (error) {
      res.status(500).json({ error: "Failed to update application status" });
    }
  });

  // Testimonial routes
  apiRouter.post("/testimonials", validateRequest(insertTestimonialSchema), async (req, res) => {
    try {
      const testimonial = await storage.createTestimonial(req.body);
      res.status(201).json(testimonial);
    } catch (error) {
      res.status(500).json({ error: "Failed to create testimonial" });
    }
  });
  
  apiRouter.get("/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getTestimonials();
      res.json(testimonials);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch testimonials" });
    }
  });

  // Register api routes
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
