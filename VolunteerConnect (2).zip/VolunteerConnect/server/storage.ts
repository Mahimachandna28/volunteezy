import { 
  users, type User, type InsertUser,
  ngos, type NGO, type InsertNGO,
  categories, type Category, type InsertCategory,
  opportunities, type Opportunity, type InsertOpportunity,
  applications, type Application, type InsertApplication,
  testimonials, type Testimonial, type InsertTestimonial
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  
  // NGO operations
  getNGO(id: number): Promise<NGO | undefined>;
  getNGOs(limit?: number, offset?: number): Promise<NGO[]>;
  getNGOsByCategory(categoryId: number): Promise<NGO[]>;
  createNGO(ngo: InsertNGO): Promise<NGO>;
  updateNGO(id: number, ngoData: Partial<InsertNGO>): Promise<NGO | undefined>;
  verifyNGO(id: number): Promise<NGO | undefined>;
  
  // Category operations
  getCategory(id: number): Promise<Category | undefined>;
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Opportunity operations
  getOpportunity(id: number): Promise<Opportunity | undefined>;
  getOpportunities(limit?: number, offset?: number): Promise<Opportunity[]>;
  getOpportunitiesByNGO(ngoId: number): Promise<Opportunity[]>;
  getOpportunitiesByCategory(categoryId: number): Promise<Opportunity[]>;
  searchOpportunities(query: string, filters?: any): Promise<Opportunity[]>;
  createOpportunity(opportunity: InsertOpportunity): Promise<Opportunity>;
  updateOpportunity(id: number, opportunityData: Partial<InsertOpportunity>): Promise<Opportunity | undefined>;
  deleteOpportunity(id: number): Promise<boolean>;
  
  // Application operations
  getApplication(id: number): Promise<Application | undefined>;
  getApplicationsByOpportunity(opportunityId: number): Promise<Application[]>;
  getApplicationsByVolunteer(volunteerId: number): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplicationStatus(id: number, status: string): Promise<Application | undefined>;
  
  // Testimonial operations
  getTestimonial(id: number): Promise<Testimonial | undefined>;
  getTestimonials(limit?: number): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private ngos: Map<number, NGO>;
  private categories: Map<number, Category>;
  private opportunities: Map<number, Opportunity>;
  private applications: Map<number, Application>;
  private testimonials: Map<number, Testimonial>;
  
  private currentUserID: number;
  private currentNGOID: number;
  private currentCategoryID: number;
  private currentOpportunityID: number;
  private currentApplicationID: number;
  private currentTestimonialID: number;

  constructor() {
    this.users = new Map();
    this.ngos = new Map();
    this.categories = new Map();
    this.opportunities = new Map();
    this.applications = new Map();
    this.testimonials = new Map();
    
    this.currentUserID = 1;
    this.currentNGOID = 1;
    this.currentCategoryID = 1;
    this.currentOpportunityID = 1;
    this.currentApplicationID = 1;
    this.currentTestimonialID = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Initialize categories
    const categoriesData: InsertCategory[] = [
      {
        name: "Education",
        description: "Teach, mentor, and support educational initiatives",
        iconName: "GraduationCap",
        colorClass: "primary"
      },
      {
        name: "Environment",
        description: "Protect nature, clean-ups, and conservation",
        iconName: "Seedling",
        colorClass: "secondary"
      },
      {
        name: "Healthcare",
        description: "Support medical camps, awareness, and care",
        iconName: "Heart",
        colorClass: "red"
      },
      {
        name: "Food Distribution",
        description: "Help with food banks and meal services",
        iconName: "Utensils",
        colorClass: "amber"
      },
      {
        name: "Community Service",
        description: "Support local community initiatives",
        iconName: "HandsHelping",
        colorClass: "purple"
      },
      {
        name: "Animal Welfare",
        description: "Support shelters and animal care initiatives",
        iconName: "Paw",
        colorClass: "blue"
      }
    ];
    
    categoriesData.forEach(category => {
      this.createCategory(category);
    });
    
    // Create sample NGOs
    const ngosData: InsertNGO[] = [
      {
        name: "Pratham Education Foundation",
        description: "Providing quality education to underprivileged children across India since 1995, focusing on innovative learning methods.",
        location: "Marol, Pune",
        category: "Education",
        email: "info@pratham.org",
        phone: "+91-22-2481-1919",
        website: "www.pratham.org",
        logoUrl: "https://images.unsplash.com/photo-1577896851231-70ef18881754?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
        isVerified: true,
        adminId: 1
      },
      {
        name: "Environmentalist Foundation of India",
        description: "Dedicated to wildlife conservation and habitat restoration across India, with a focus on lake and pond restoration projects.",
        location: "Alandur, Hyderabad",
        category: "Environment",
        email: "contact@indiaenvironment.org",
        phone: "+91-44-4850-3322",
        website: "www.indiaenvironment.org",
        logoUrl: "https://images.unsplash.com/photo-1516557070061-c3d1653fa646?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
        isVerified: true,
        adminId: 2
      },
      {
        name: "Smile Foundation",
        description: "Working for the health and education of underprivileged children and youth across 25 states of India.",
        location: "Gomti Nagar, Lucknow",
        category: "Healthcare",
        email: "info@smilefoundationindia.org",
        phone: "+91-11-4319-9100",
        website: "www.smilefoundationindia.org",
        logoUrl: "https://images.unsplash.com/photo-1576765607924-3f7b8410a787?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
        isVerified: true,
        adminId: 3
      },
      {
        name: "Akshaya Patra Foundation",
        description: "Providing nutritious mid-day meals to school children across India, serving millions of children daily in government schools.",
        location: "Salt Lake, Kolkata",
        category: "Food Distribution",
        email: "contact@akshayapatra.org",
        phone: "+91-80-6623-2323",
        website: "www.akshayapatra.org",
        logoUrl: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
        isVerified: true,
        adminId: 4
      },
      {
        name: "People For Animals",
        description: "India's largest animal welfare organization with shelters, hospitals and rescue services in major cities across the country.",
        location: "Navrangpura, Ahmedabad",
        category: "Animal Welfare",
        email: "contact@peopleforanimalsindia.org",
        phone: "+91-11-2686-5873",
        website: "www.peopleforanimalsindia.org",
        logoUrl: "https://images.unsplash.com/photo-1505628346881-b72b27e84530?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
        isVerified: true,
        adminId: 5
      },
      {
        name: "HelpAge India",
        description: "Working for the dignity, healthcare and rights of disadvantaged elderly in India through various intervention programs.",
        location: "Panjim, Goa",
        category: "Community Service",
        email: "info@helpageindia.org",
        phone: "+91-11-4165-3333",
        website: "www.helpageindia.org",
        logoUrl: "https://images.unsplash.com/photo-1591275843051-e7c2c29de661?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
        isVerified: true,
        adminId: 6
      }
    ];
    
    // Create user admins first
    for (let i = 1; i <= ngosData.length; i++) {
      this.createUser({
        username: `admin${i}`,
        password: "password123",
        email: `admin${i}@example.com`,
        fullName: `Admin ${i}`,
        userType: "ngo_admin",
        location: ngosData[i-1].location,
        bio: `Administrator for ${ngosData[i-1].name}`,
        phone: ngosData[i-1].phone,
        profileImage: "",
        skills: [],
        interests: []
      });
    }
    
    // Then create NGOs
    ngosData.forEach(ngo => {
      this.createNGO(ngo);
    });
    
    // Create sample opportunities
    const opportunitiesData: InsertOpportunity[] = [
      {
        title: "Educational Support Mentor",
        description: "Help children from low-income communities with their studies and provide educational guidance. Make a significant impact on their future.",
        ngoId: 1,
        categoryId: 1,
        location: "Marol, Pune",
        startDate: new Date("2023-09-15"),
        endDate: new Date("2023-12-15"),
        schedule: "Weekdays",
        duration: "2-3 Hours",
        requirements: "Basic knowledge in mathematics, science, or English. Patience and good communication skills required.",
        spotsAvailable: 10
      },
      {
        title: "Lake Restoration Volunteer",
        description: "Join our team in restoring urban lakes and ponds in Hyderabad. Help with cleanup, planting, and monitoring water quality.",
        ngoId: 2,
        categoryId: 2,
        location: "Alandur, Hyderabad",
        startDate: new Date("2023-09-01"),
        endDate: new Date("2023-11-30"),
        schedule: "Weekends",
        duration: "4 Hours",
        requirements: "No experience needed. Bring water and sun protection. Comfortable working outdoors in various weather conditions.",
        spotsAvailable: 15
      },
      {
        title: "Community Health Camp",
        description: "Support healthcare professionals in conducting health awareness and basic screening camps in underserved areas of Lucknow.",
        ngoId: 3,
        categoryId: 3,
        location: "Gomti Nagar, Lucknow",
        startDate: new Date("2023-10-02"),
        endDate: new Date("2023-10-02"),
        schedule: "One-time",
        duration: "Full Day",
        requirements: "No medical experience required. Training will be provided on-site. Fluency in Hindi preferred.",
        spotsAvailable: 8
      },
      {
        title: "Mid-day Meal Program Assistant",
        description: "Help prepare and distribute nutritious meals to schoolchildren, ensuring they receive proper nourishment for their studies.",
        ngoId: 4,
        categoryId: 4,
        location: "Salt Lake, Kolkata",
        startDate: new Date("2023-09-01"),
        endDate: null,
        schedule: "Flexible",
        duration: "3 Hours",
        requirements: "Food handling experience preferred but not required. Training will be provided.",
        spotsAvailable: 20
      },
      {
        title: "Animal Rescue and Care",
        description: "Assist with rescuing injured animals, providing basic care, and helping with feeding and shelter maintenance.",
        ngoId: 5,
        categoryId: 6,
        location: "Navrangpura, Ahmedabad",
        startDate: new Date("2023-09-01"),
        endDate: null,
        schedule: "Weekly",
        duration: "4 Hours",
        requirements: "Compassion for animals, ability to handle various animals, minimum age 18.",
        spotsAvailable: 12
      },
      {
        title: "Elder Care Visitor",
        description: "Provide companionship to elderly individuals in care homes through regular visits, engaging in conversation, and helping with basic needs.",
        ngoId: 6,
        categoryId: 5,
        location: "Panjim, Goa",
        startDate: new Date("2023-09-01"),
        endDate: null,
        schedule: "Flexible",
        duration: "2 Hours",
        requirements: "Patience, good communication skills, respect for elders. Background verification required.",
        spotsAvailable: 25
      }
    ];
    
    opportunitiesData.forEach(opportunity => {
      this.createOpportunity(opportunity);
    });
    
    // Create sample testimonials
    const testimonialsData: InsertTestimonial[] = [
      {
        userId: 7,
        content: "Volunteezy connected me with Pratham Education Foundation where I teach English to children from underprivileged backgrounds. It's incredibly fulfilling to see these young minds develop language skills that will open doors for them.",
        userType: "volunteer",
        organization: "",
        location: "Kothrud, Pune",
        imageUrl: "https://images.unsplash.com/photo-1552058544-f2b08422138a?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
      },
      {
        userId: 3,
        content: "As a representative of Smile Foundation, Volunteezy has helped us find committed volunteers for our healthcare initiatives across Lucknow. The quality of volunteers and the streamlined process has been a game-changer for our programs.",
        userType: "ngo_admin",
        organization: "Smile Foundation",
        location: "Hazratganj, Lucknow",
        imageUrl: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
      },
      {
        userId: 8,
        content: "I've been volunteering with EFI's lake restoration projects in Hyderabad. The work is challenging but rewarding, and I've met wonderful people who are passionate about protecting our environment. Volunteezy made finding this opportunity seamless.",
        userType: "volunteer",
        organization: "",
        location: "Banjara Hills, Hyderabad",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
      }
    ];
    
    // Create volunteer users for testimonials
    this.createUser({
      username: "priyaR",
      password: "password123",
      email: "priya@example.com",
      fullName: "Priya Ramachandran",
      userType: "volunteer",
      location: "Kothrud, Pune",
      bio: "Teacher with passion for empowering children through education",
      phone: "+91-98765-43210",
      profileImage: "https://images.unsplash.com/photo-1552058544-f2b08422138a?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      skills: ["Teaching", "English Language", "Mentoring"],
      interests: ["Education", "Child Development", "Literacy"]
    });
    
    this.createUser({
      username: "vikram87",
      password: "password123",
      email: "vikram@example.com",
      fullName: "Vikram Singh",
      userType: "volunteer",
      location: "Banjara Hills, Hyderabad",
      bio: "Environmental engineering graduate committed to ecological restoration",
      phone: "+91-87654-32109",
      profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
      skills: ["Environmental Conservation", "Project Management", "Community Outreach"],
      interests: ["Ecology", "Water Conservation", "Sustainability"]
    });
    
    testimonialsData.forEach(testimonial => {
      this.createTestimonial(testimonial);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.currentUserID++;
    const createdAt = new Date();
    const newUser: User = { 
      ...user, 
      id, 
      createdAt,
      location: user.location || null,
      bio: user.bio || null,
      phone: user.phone || null,
      profileImage: user.profileImage || null,
      skills: user.skills || null,
      interests: user.interests || null
    };
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // NGO operations
  async getNGO(id: number): Promise<NGO | undefined> {
    return this.ngos.get(id);
  }
  
  async getNGOs(limit: number = 100, offset: number = 0): Promise<NGO[]> {
    return Array.from(this.ngos.values())
      .sort((a, b) => a.id - b.id)
      .slice(offset, offset + limit);
  }
  
  async getNGOsByCategory(categoryId: number): Promise<NGO[]> {
    const category = await this.getCategory(categoryId);
    if (!category) return [];
    
    return Array.from(this.ngos.values()).filter(
      (ngo) => ngo.category === category.name
    );
  }
  
  async createNGO(ngo: InsertNGO): Promise<NGO> {
    const id = this.currentNGOID++;
    const createdAt = new Date();
    const newNGO: NGO = { 
      ...ngo, 
      id, 
      createdAt,
      website: ngo.website || null,
      logoUrl: ngo.logoUrl || null,
      isVerified: ngo.isVerified || false
    };
    this.ngos.set(id, newNGO);
    return newNGO;
  }
  
  async updateNGO(id: number, ngoData: Partial<InsertNGO>): Promise<NGO | undefined> {
    const ngo = this.ngos.get(id);
    if (!ngo) return undefined;
    
    const updatedNGO: NGO = { ...ngo, ...ngoData };
    this.ngos.set(id, updatedNGO);
    return updatedNGO;
  }
  
  async verifyNGO(id: number): Promise<NGO | undefined> {
    const ngo = this.ngos.get(id);
    if (!ngo) return undefined;
    
    const verifiedNGO: NGO = { ...ngo, isVerified: true };
    this.ngos.set(id, verifiedNGO);
    return verifiedNGO;
  }

  // Category operations
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.currentCategoryID++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }

  // Opportunity operations
  async getOpportunity(id: number): Promise<Opportunity | undefined> {
    return this.opportunities.get(id);
  }
  
  async getOpportunities(limit: number = 100, offset: number = 0): Promise<Opportunity[]> {
    return Array.from(this.opportunities.values())
      .sort((a, b) => a.id - b.id)
      .slice(offset, offset + limit);
  }
  
  async getOpportunitiesByNGO(ngoId: number): Promise<Opportunity[]> {
    return Array.from(this.opportunities.values()).filter(
      (opportunity) => opportunity.ngoId === ngoId
    );
  }
  
  async getOpportunitiesByCategory(categoryId: number): Promise<Opportunity[]> {
    return Array.from(this.opportunities.values()).filter(
      (opportunity) => opportunity.categoryId === categoryId
    );
  }
  
  async searchOpportunities(query: string, filters: any = {}): Promise<Opportunity[]> {
    let results = Array.from(this.opportunities.values());
    
    // Search by title or description
    if (query) {
      const lowercaseQuery = query.toLowerCase();
      results = results.filter(
        (opportunity) => 
          opportunity.title.toLowerCase().includes(lowercaseQuery) ||
          opportunity.description.toLowerCase().includes(lowercaseQuery) ||
          opportunity.location.toLowerCase().includes(lowercaseQuery)
      );
    }
    
    // Apply filters
    if (filters.category) {
      results = results.filter(
        (opportunity) => opportunity.categoryId === parseInt(filters.category)
      );
    }
    
    if (filters.location) {
      results = results.filter(
        (opportunity) => opportunity.location === filters.location
      );
    }
    
    if (filters.schedule) {
      results = results.filter(
        (opportunity) => opportunity.schedule === filters.schedule
      );
    }
    
    if (filters.duration) {
      results = results.filter(
        (opportunity) => opportunity.duration === filters.duration
      );
    }
    
    return results;
  }
  
  async createOpportunity(opportunity: InsertOpportunity): Promise<Opportunity> {
    const id = this.currentOpportunityID++;
    const createdAt = new Date();
    const newOpportunity: Opportunity = { 
      ...opportunity, 
      id, 
      createdAt,
      startDate: opportunity.startDate || null,
      endDate: opportunity.endDate || null,
      requirements: opportunity.requirements || null,
      spotsAvailable: opportunity.spotsAvailable || null
    };
    this.opportunities.set(id, newOpportunity);
    return newOpportunity;
  }
  
  async updateOpportunity(id: number, opportunityData: Partial<InsertOpportunity>): Promise<Opportunity | undefined> {
    const opportunity = this.opportunities.get(id);
    if (!opportunity) return undefined;
    
    const updatedOpportunity: Opportunity = { ...opportunity, ...opportunityData };
    this.opportunities.set(id, updatedOpportunity);
    return updatedOpportunity;
  }
  
  async deleteOpportunity(id: number): Promise<boolean> {
    return this.opportunities.delete(id);
  }

  // Application operations
  async getApplication(id: number): Promise<Application | undefined> {
    return this.applications.get(id);
  }
  
  async getApplicationsByOpportunity(opportunityId: number): Promise<Application[]> {
    return Array.from(this.applications.values()).filter(
      (application) => application.opportunityId === opportunityId
    );
  }
  
  async getApplicationsByVolunteer(volunteerId: number): Promise<Application[]> {
    return Array.from(this.applications.values()).filter(
      (application) => application.volunteerId === volunteerId
    );
  }
  
  async createApplication(application: InsertApplication): Promise<Application> {
    const id = this.currentApplicationID++;
    const createdAt = new Date();
    const newApplication: Application = { 
      ...application, 
      id, 
      createdAt,
      status: "pending",
      message: application.message || null
    };
    this.applications.set(id, newApplication);
    return newApplication;
  }
  
  async updateApplicationStatus(id: number, status: string): Promise<Application | undefined> {
    const application = this.applications.get(id);
    if (!application) return undefined;
    
    const updatedApplication: Application = { ...application, status };
    this.applications.set(id, updatedApplication);
    return updatedApplication;
  }

  // Testimonial operations
  async getTestimonial(id: number): Promise<Testimonial | undefined> {
    return this.testimonials.get(id);
  }
  
  async getTestimonials(limit: number = 100): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values())
      .sort((a, b) => a.id - b.id)
      .slice(0, limit);
  }
  
  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.currentTestimonialID++;
    const createdAt = new Date();
    const newTestimonial: Testimonial = { 
      ...testimonial, 
      id, 
      createdAt,
      location: testimonial.location || null,
      organization: testimonial.organization || null,
      imageUrl: testimonial.imageUrl || null
    };
    this.testimonials.set(id, newTestimonial);
    return newTestimonial;
  }
}

export const storage = new MemStorage();
